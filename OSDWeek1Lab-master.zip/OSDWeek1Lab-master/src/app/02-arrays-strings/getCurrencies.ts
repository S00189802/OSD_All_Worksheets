export function getCurrencies(){
    return ['USD','GDP','EUR'];
}